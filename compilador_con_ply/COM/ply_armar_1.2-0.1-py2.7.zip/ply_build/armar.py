# -*- enconding: utf-8 -*-
import os


def Analizador_sintacito():
    a = raw_input("direccion: ")
    if (os.path.exists(a)):
        os.system("g++ -Wall -c    " + a)
        os.system("rm -r *.o")
    else:
        print "Error en el nombre del archivo"


def OBJ():
    a = raw_input("direccion: ")
    if (os.path.exists(a)):
        os.system("g++ -Wall -c " + a)
        os.system("pause")


def EXE():
    a = raw_input("direccion: ")
    if (os.path.exists(a)):
        os.system("g++ -Wall -o " + "exe " + a)
        os.system("pause")
    #os.system("xterm ./exe")


def RUN():
    os.system("xterm ./exe")

